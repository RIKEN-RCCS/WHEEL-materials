#!/bin/bash
echo "start ${0}"

MOTORBIKE_PATH="../motorBike/"
MESH_PATH="../../mesh/"
MESH_REMOTE_PATH="${MESH_PATH}01_RemoteTask/motorBike/"

if [ -e $MOTORBIKE_PATH ]; then
    rm -rf $MOTORBIKE_PATH
fi

cp -r "$MESH_REMOTE_PATH" ../

exit $?
