#!/bin/bash
CHECK_SOLVER="./check_solver"

if [ -f $CHECK_SOLVER ] && ! grep -q "failed" $CHECK_SOLVER ; then
    exit 0
else
    exit 1
fi