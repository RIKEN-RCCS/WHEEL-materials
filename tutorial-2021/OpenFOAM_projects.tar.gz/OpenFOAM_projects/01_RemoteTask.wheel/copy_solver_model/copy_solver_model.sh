#!/bin/bash
echo "start ${0}"

MOTORBIKE_PATH="../motorBike/"
SOLVER_PATH="../../solver/"
SOLVER_REMOTE_PATH="${SOLVER_PATH}01_RemoteTask/"
POST_PROCESSING_PATH="${MOTORBIKE_PATH}postProcessing/"

if [ -e $SOLVER_PATH ]; then
    if [ -e "$SOLVER_REMOTE_PATH" ]; then
        rm -rf "$SOLVER_REMOTE_PATH"
    fi
    mkdir "$SOLVER_REMOTE_PATH"
else
    mkdir $SOLVER_PATH
    mkdir "$SOLVER_REMOTE_PATH"
fi

if [ -d $POST_PROCESSING_PATH ]; then
    echo "solver succeed" > ./check_solver
else
    echo "solver failed" > ./check_solver
fi

cp -r $MOTORBIKE_PATH "${SOLVER_REMOTE_PATH}motorBike/"

exit $? 
