#!/bin/bash
echo "start ${0}"

MOTOR_BIKE="./motorBike.tar.gz"

tar -zxvf $MOTOR_BIKE -C ../

exit $?
