#!/bin/bash
echo "start ${0}"

MESH_PATH="../../mesh/"
MESH_REMOTE_PATH="${MESH_PATH}01_RemoteTask/"
MOTORBIKE_PATH="../motorBike/"
MESH_LOG="${MOTORBIKE_PATH}log.checkMesh"

if [ -e $MESH_PATH ]; then
    if [ -e $MESH_REMOTE_PATH ]; then
        rm -rf $MESH_REMOTE_PATH
    fi
    mkdir $MESH_REMOTE_PATH
else
    mkdir $MESH_PATH
    mkdir $MESH_REMOTE_PATH
fi

if [ -f $MESH_LOG ]; then
    cp $MESH_LOG ./meshLog
fi

cp -r $MOTORBIKE_PATH "${MESH_REMOTE_PATH}motorBike/"

exit $?