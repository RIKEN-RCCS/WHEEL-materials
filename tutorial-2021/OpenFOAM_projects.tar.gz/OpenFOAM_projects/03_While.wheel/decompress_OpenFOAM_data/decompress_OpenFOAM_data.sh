#!/bin/bash
echo "start ${0}"

MOTOR_BIKE="./motorBike_U_param.tar.gz"

tar -zxvf $MOTOR_BIKE -C ../

exit $?