#!/bin/bash
echo "start ${0}"

MESH_PATH="../../mesh/"
MESH_WHILE_PATH="${MESH_PATH}03_While/"
MOTORBIKE_PATH="../motorBike/"
MESH_LOG="${MOTORBIKE_PATH}log.checkMesh"

if [ -e $MESH_PATH ]; then
    if [ -e $MESH_WHILE_PATH ]; then
        rm -rf $MESH_WHILE_PATH
    fi
    mkdir $MESH_WHILE_PATH
else
    mkdir $MESH_PATH
    mkdir $MESH_WHILE_PATH
fi

if [ -f $MESH_LOG ]; then
    cp $MESH_LOG ./meshLog
fi

cp -r $MOTORBIKE_PATH "${MESH_WHILE_PATH}motorBike/"

exit $?