#!/bin/bash
LOG_CHECK_MESH="./meshLog"

if [ -f $LOG_CHECK_MESH ] && ! grep -q "Error" $LOG_CHECK_MESH ; then
    exit 0
else
    exit 1
fi
