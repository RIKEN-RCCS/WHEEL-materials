#!/bin/bash
#PJM -L "rscgrp=small"
#PJM -L "node=1"
#PJM --mpi proc=6
#PJM -L "elapse=1:00:00"
#PJM -s

MOTORBIKE_PATH="../motorBike/"

cd $MOTORBIKE_PATH || exit 1

. /vol0004/apps/oss/spack/share/spack/setup-env.sh
spack load openfoam@2012

. /$WM_PROJECT_DIR/bin/tools/RunFunctions

runParallel simpleFoam

runApplication reconstructParMesh -constant -mergeTol 1e-06
runApplication reconstructPar -latestTime

exit 0
