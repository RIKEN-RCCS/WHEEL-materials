#!/bin/bash
echo "start ${0}"

INITIAL_CONDITIONS_PATH="../motorBike/*"

array_U=($(cat ./U_param|xargs))
grep -r -l -i "U_Param" $INITIAL_CONDITIONS_PATH | xargs sed -i -e "s/U_param/${array_U[$WHEEL_CURRENT_INDEX]}/g"

exit $?