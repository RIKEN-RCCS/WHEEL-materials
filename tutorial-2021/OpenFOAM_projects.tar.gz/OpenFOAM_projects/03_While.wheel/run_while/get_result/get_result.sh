#!/bin/bash
echo "start ${0}"

if [ -f ../../p_result ]; then
    rm ../../p_result
fi
array_p_result=($(tail -n 1 ./p|xargs))
echo ${array_p_result[1]} | awk '{printf("%d\n",$1)}' > ../../p_result

exit $?