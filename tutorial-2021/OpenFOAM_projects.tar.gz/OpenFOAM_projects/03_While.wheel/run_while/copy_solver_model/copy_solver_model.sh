#!/bin/bash
echo "start ${0}"

MOTORBIKE_PATH="../motorBike/"
SOLVER_PATH="../../../solver/"
CHECK_SOLVER="./check_solver"
SOLVER_WHILE_PATH="${SOLVER_PATH}03_While/"
POST_PROCESSING_PATH="${MOTORBIKE_PATH}postProcessing/"

if [ -e $SOLVER_PATH ]; then
    if [ -e "$SOLVER_WHILE_PATH" ]; then
        rm -rf "$SOLVER_WHILE_PATH"
    fi
    mkdir "$SOLVER_WHILE_PATH"
else
    mkdir $SOLVER_PATH
    mkdir "$SOLVER_WHILE_PATH"
fi

if [ -f $CHECK_SOLVER ]; then
    rm $CHECK_SOLVER
fi

if [ -d $POST_PROCESSING_PATH ]; then
    cp "${MOTORBIKE_PATH}postProcessing/probes/0/p" ./
    echo "solver succeed" > $CHECK_SOLVER
else
    echo "solver failed" > $CHECK_SOLVER
fi

cp -r $MOTORBIKE_PATH "${SOLVER_WHILE_PATH}motorBike/"

exit $?
