#!/bin/bash
P_RESULT_PATH="../p_result"

if [ -f $P_RESULT_PATH ]; then
    p_result=($(cat $P_RESULT_PATH|xargs))
    if  [ $p_result -lt 20 ]; then
        exit 0
    else
        exit 1
    fi
elif [ $WHEEL_CURRENT_INDEX -gt 3 ]; then
    exit 1
else
    exit 0
fi
