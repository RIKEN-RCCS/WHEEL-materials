#!/bin/bash
#PJM -L "rscgrp=small"
#PJM -L "node=1"
#PJM --mpi proc=1
#PJM -L "elapse=1:00:00"
#PJM -s

. /vol0004/apps/oss/spack/share/spack/setup-env.sh
spack load paraview/e2h2vl5

mpirun -n 1 pvbatch motorBike_pvbatch.py

exit 0