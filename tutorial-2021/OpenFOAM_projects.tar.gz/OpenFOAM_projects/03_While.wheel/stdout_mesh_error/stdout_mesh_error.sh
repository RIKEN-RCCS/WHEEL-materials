#!/bin/bash
echo "start ${0}"

MOTORBIKE_PATH="../motorBike/"

echo "Meshing Error"

cd $MOTORBIKE_PATH || exit 1
echo "A complete log can be found in:"
echo "$(pwd)/log.checkMesh"

exit 0