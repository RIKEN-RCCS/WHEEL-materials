#!/bin/bash
echo "start ${0}"

MOTORBIKE_PATH="../motorBike/"
SOLVER_PATH="../../solver/"
SOLVER_WHILE_PATH="${SOLVER_PATH}03_While/motorBike/"

if [ -e $MOTORBIKE_PATH ]; then
    rm -rf $MOTORBIKE_PATH
fi

cp -r "$SOLVER_WHILE_PATH" ../

exit $?
