# trace generated using paraview version 5.7.0
#
# To ensure correct image size when batch processing, please search 
# for and uncomment the line `# renderView*.ViewSize = [*,*]`

#### import the simple module from the paraview
from paraview.simple import *
#### disable automatic camera reset on 'Show'
paraview.simple._DisableFirstRenderCameraReset()

# get active view
renderView1 = GetActiveViewOrCreate('RenderView')
# uncomment following to set a specific view size
renderView1.ViewSize = [1360, 579]

# reset view to fit data
renderView1.ResetCamera()

# create a new 'OpenFOAMReader'
input_dir_path = '../motorBike/'
output_file_name = 'result.png'
afoam = OpenFOAMReader(FileName=input_dir_path + 'a.foam')

afoam.MeshRegions = ['internalMesh']
afoam.CellArrays = ['U', 'UNear', 'k', 'nut', 'omega', 'p']

# show data in view
afoamDisplay = Show(afoam, renderView1)

# get color transfer function/color map for 'p'
pLUT = GetColorTransferFunction('p')

# get opacity transfer function/opacity map for 'p'
pPWF = GetOpacityTransferFunction('p')

# trace defaults for the display properties.
afoamDisplay.Representation = 'Surface'
afoamDisplay.ColorArrayName = ['POINTS', 'p']
afoamDisplay.LookupTable = pLUT
afoamDisplay.OSPRayScaleArray = 'p'
afoamDisplay.OSPRayScaleFunction = 'PiecewiseFunction'
afoamDisplay.SelectOrientationVectors = 'U'
afoamDisplay.ScaleFactor = 2.0
afoamDisplay.SelectScaleArray = 'p'
afoamDisplay.GlyphType = 'Arrow'
afoamDisplay.GlyphTableIndexArray = 'p'
afoamDisplay.GaussianRadius = 0.1
afoamDisplay.SetScaleArray = ['POINTS', 'p']
afoamDisplay.ScaleTransferFunction = 'PiecewiseFunction'
afoamDisplay.OpacityArray = ['POINTS', 'p']
afoamDisplay.OpacityTransferFunction = 'PiecewiseFunction'
afoamDisplay.DataAxesGrid = 'GridAxesRepresentation'
afoamDisplay.PolarAxes = 'PolarAxesRepresentation'
afoamDisplay.ScalarOpacityFunction = pPWF
afoamDisplay.ScalarOpacityUnitDistance = 0.2603930082417861
afoamDisplay.ExtractedBlockIndex = 1

# init the 'PiecewiseFunction' selected for 'ScaleTransferFunction'
afoamDisplay.ScaleTransferFunction.Points = [-828.8489990234375, 0.0, 0.5, 0.0, 195.60499572753906, 1.0, 0.5, 0.0]

# init the 'PiecewiseFunction' selected for 'OpacityTransferFunction'
afoamDisplay.OpacityTransferFunction.Points = [-828.8489990234375, 0.0, 0.5, 0.0, 195.60499572753906, 1.0, 0.5, 0.0]

# reset view to fit data
renderView1.ResetCamera()

# get the material library
materialLibrary1 = GetMaterialLibrary()

# show color bar/color legend
afoamDisplay.SetScalarBarVisibility(renderView1, True)

# update the view to ensure updated data information
renderView1.Update()

# create a new 'Slice'
slice1 = Slice(Input=afoam)
slice1.SliceType = 'Plane'
slice1.SliceOffsetValues = [0.0]

# init the 'Plane' selected for 'SliceType'
slice1.SliceType.Origin = [5.0, 0.0, 4.0]

# Properties modified on slice1.SliceType
slice1.SliceType.Normal = [0.0, 1.0, 0.0]

# show data in view
slice1Display = Show(slice1, renderView1)

# trace defaults for the display properties.
slice1Display.Representation = 'Surface'
slice1Display.ColorArrayName = ['POINTS', 'p']
slice1Display.LookupTable = pLUT
slice1Display.OSPRayScaleArray = 'p'
slice1Display.OSPRayScaleFunction = 'PiecewiseFunction'
slice1Display.SelectOrientationVectors = 'U'
slice1Display.ScaleFactor = 2.0
slice1Display.SelectScaleArray = 'p'
slice1Display.GlyphType = 'Arrow'
slice1Display.GlyphTableIndexArray = 'p'
slice1Display.GaussianRadius = 0.1
slice1Display.SetScaleArray = ['POINTS', 'p']
slice1Display.ScaleTransferFunction = 'PiecewiseFunction'
slice1Display.OpacityArray = ['POINTS', 'p']
slice1Display.OpacityTransferFunction = 'PiecewiseFunction'
slice1Display.DataAxesGrid = 'GridAxesRepresentation'
slice1Display.PolarAxes = 'PolarAxesRepresentation'

# init the 'PiecewiseFunction' selected for 'ScaleTransferFunction'
slice1Display.ScaleTransferFunction.Points = [-277.2334899902344, 0.0, 0.5, 0.0, 195.3013916015625, 1.0, 0.5, 0.0]

# init the 'PiecewiseFunction' selected for 'OpacityTransferFunction'
slice1Display.OpacityTransferFunction.Points = [-277.2334899902344, 0.0, 0.5, 0.0, 195.3013916015625, 1.0, 0.5, 0.0]

# hide data in view
Hide(afoam, renderView1)

# show color bar/color legend
slice1Display.SetScalarBarVisibility(renderView1, True)

# update the view to ensure updated data information
renderView1.Update()

# set scalar coloring
ColorBy(slice1Display, ('POINTS', 'U', 'Magnitude'))

# Hide the scalar bar for this color map if no visible data is colored by it.
HideScalarBarIfNotNeeded(pLUT, renderView1)

# rescale color and/or opacity maps used to include current data range
slice1Display.RescaleTransferFunctionToDataRange(True, False)

# show color bar/color legend
slice1Display.SetScalarBarVisibility(renderView1, True)

# get color transfer function/color map for 'U'
uLUT = GetColorTransferFunction('U')

# get opacity transfer function/opacity map for 'U'
uPWF = GetOpacityTransferFunction('U')

# set active source
SetActiveSource(afoam)

# show data in view
afoamDisplay = Show(afoam, renderView1)

# show color bar/color legend
afoamDisplay.SetScalarBarVisibility(renderView1, True)

# Properties modified on afoamDisplay
# afoamDisplay.Opacity = 0.5

#### saving camera placements for all active views

# current camera placement for renderView1
renderView1.CameraPosition = [1.0, -4, 1.0]
renderView1.CameraFocalPoint = [1.0, 0.0, 1.0]
renderView1.CameraViewUp = [0.0, 0.0, 1.0]
renderView1.CameraParallelScale = 15

#### uncomment the following to render all views
# RenderAllViews()
# alternatively, if you want to write images, you can use SaveScreenshot(...).

# 手で追加
Render()
WriteImage(input_dir_path + output_file_name)
