#!/bin/bash
CHECK_RESULT="./check_result"

if [ -f $CHECK_RESULT ] && ! grep -q "failed" $CHECK_RESULT ; then
    exit 0
else
    exit 1
fi