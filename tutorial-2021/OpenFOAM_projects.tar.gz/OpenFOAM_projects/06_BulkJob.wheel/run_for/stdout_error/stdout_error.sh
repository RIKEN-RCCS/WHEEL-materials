#!/bin/bash
echo "start ${0}"

echo "Error"
cd ../../run_bulkjob/ || exit 1
echo "A complete log can be found in:"
echo $(pwd)

exit 0