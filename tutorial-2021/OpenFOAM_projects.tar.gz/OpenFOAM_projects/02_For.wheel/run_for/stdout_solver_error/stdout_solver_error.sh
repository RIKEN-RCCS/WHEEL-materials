#!/bin/bash
echo "start ${0}"

MESH_PATH="../../../mesh/"
MESH_FOR_PATH="${MESH_PATH}02_For/"

echo "Solver Error"

cd ../run_solver/ || exit 1
echo "A complete log can be found in:"
echo $(pwd)

cd $MESH_FOR_PATH || exit 1
echo "Please review the solver conditions"
echo $(pwd)

exit 0