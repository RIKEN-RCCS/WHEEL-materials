#!/bin/bash
echo "start ${0}"

MOTORBIKE_PATH="../motorBike/"
MESH_PATH="../../../mesh/"
MESH_FOR_PATH="${MESH_PATH}02_For/motorBike/"

if [ -e $MOTORBIKE_PATH ]; then
    rm -rf $MOTORBIKE_PATH
fi

cp -r "$MESH_FOR_PATH" ../

exit $?
