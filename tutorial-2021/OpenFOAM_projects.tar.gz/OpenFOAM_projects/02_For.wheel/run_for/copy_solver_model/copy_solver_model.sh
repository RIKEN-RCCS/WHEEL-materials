#!/bin/bash
echo "start ${0}"

MOTORBIKE_PATH="../motorBike/"
SOLVER_PATH="../../../solver/"
CHECK_SOLVER="./check_solver"
SOLVER_FOR_PATH="${SOLVER_PATH}02_For_${WHEEL_CURRENT_INDEX}/"
POST_PROCESSING_PATH="${MOTORBIKE_PATH}postProcessing/"

if [ -e $SOLVER_PATH ]; then
    if [ -e "$SOLVER_FOR_PATH" ]; then
        rm -rf "$SOLVER_FOR_PATH"
    fi
    mkdir "$SOLVER_FOR_PATH"
else
    mkdir $SOLVER_PATH
    mkdir "$SOLVER_FOR_PATH"
fi

if [ -f $CHECK_SOLVER ]; then
    rm $CHECK_SOLVER
fi

if [ -d $POST_PROCESSING_PATH ]; then
    echo "solver succeed" > $CHECK_SOLVER
else
    echo "solver failed" > $CHECK_SOLVER
fi

cp -r $MOTORBIKE_PATH "${SOLVER_FOR_PATH}motorBike/"

exit $?
