#!/bin/bash
echo "start ${0}"

MESH_PATH="../../mesh/"
MESH_FOR_PATH="${MESH_PATH}02_For/"
MOTORBIKE_PATH="../motorBike/"
MESH_LOG="${MOTORBIKE_PATH}log.checkMesh"

if [ -e $MESH_PATH ]; then
    if [ -e $MESH_FOR_PATH ]; then
        rm -rf $MESH_FOR_PATH
    fi
    mkdir $MESH_FOR_PATH    
else
    mkdir $MESH_PATH
    mkdir $MESH_FOR_PATH
fi

if [ -f $MESH_LOG ]; then
    cp $MESH_LOG ./meshLog
fi

cp -r $MOTORBIKE_PATH "${MESH_FOR_PATH}motorBike/"

exit $?