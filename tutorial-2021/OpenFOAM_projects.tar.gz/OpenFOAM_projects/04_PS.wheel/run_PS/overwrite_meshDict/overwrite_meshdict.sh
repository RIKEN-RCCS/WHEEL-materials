#!/bin/bash
echo "start ${0}"

MOTORBIKE_PATH="../motorBike/"

if [ -e $MOTORBIKE_PATH ]; then 
    cp -f ./blockMeshDict ${MOTORBIKE_PATH}/system/blockMeshDict
else
    exit 1
fi

exit 0