#!/bin/bash
echo "start ${0}"

MOTORBIKE_PATH="../motorBike/"

if [ -d "$MOTORBIKE_PATH"postProcessing/ ]; then
    echo "succeed" > ./check_result
else
    echo "failed" > ./check_result
fi

exit $? 
